#!/bin/bash
#
#
# Added by Scott Vitale for AttoBASIC support
make clean > /dev/null 2>&1 ; make TN85-1M > /dev/null 2>&1
make clean > /dev/null 2>&1 ; make TN85-2M > /dev/null 2>&1
make clean > /dev/null 2>&1 ; make TN85-4M > /dev/null 2>&1
make clean > /dev/null 2>&1 ; make TN85-8M > /dev/null 2>&1
make clean > /dev/null 2>&1 ; make TN85-10M > /dev/null 2>&1
make clean > /dev/null 2>&1 ; make TN85-16M > /dev/null 2>&1
make clean > /dev/null 2>&1 ; make TN85-20M > /dev/null 2>&1
make clean > /dev/null 2>&1
