avrdude 6.0.1 mods to support picoboot.
pre-compiled binary available at http://162.248.164.251/files/
