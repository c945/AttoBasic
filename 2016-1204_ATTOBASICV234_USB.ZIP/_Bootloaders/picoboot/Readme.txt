This folder contains a number of bootloaders and support files.
Note: only picobootSerial is being maintained

File name           Description
-----------------------------------
picobootSerial.S    Soft UART bootloader in 64 bytes - uses avrdude fork for uploading
boot.S              SPI-based prototype - obsolete
picobootSTK500.S    arduino compatible bootloader prototype
BBUart.S            Soft UART in 26 instructions
AVR305.S            optimized AVR305 soft UART
