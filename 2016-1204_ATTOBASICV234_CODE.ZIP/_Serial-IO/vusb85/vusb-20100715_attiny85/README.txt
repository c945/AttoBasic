This is the source code package for V-USB with ATtiny45 / ATtiny85 tutorial by Joonas Pihlajamaa, published at Code and Life blog, http://codeandlife.com:

http://codeandlife.com/2012/02/22/v-usb-with-attiny45-attiny85-without-a-crystal/

The subfolders contain parts of libusb-win32 available at http://sourceforge.net/apps/trac/libusb-win32/wiki and V-USB library available at http://www.obdev.at/avrusb/ and their contents are copyrighted by their respective authors. My productions in the root folder are published under GNU GPL v3 (see License.txt).

I hope you have fun with this project!

- Joonas Pihlajamaa