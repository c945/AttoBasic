#! /bin/bash

while true ; do
  killall wineserver winconsole.exe WineBuild.sh ;
done
